import React from "react";
import { getPokemonListResponse } from "../../../api/pokemon/pokemon.response.types";
import PokemonCard from "../PokemonCard";
import styles from "./PokemonList.module.css";

interface PokemonListProps {
  data: getPokemonListResponse;
  onCardClick: (id: number) => void;
}

const PokemonList: React.FC<PokemonListProps> = ({ data, onCardClick }) => {
  return (
    <div className={styles.container}>
      {data.results.map((pokemon, index) => {
        const pokemonId = index + 1;
        return (
          <PokemonCard
            key={pokemonId}
            id={pokemonId}
            name={pokemon.name}
            onClick={() => onCardClick(pokemonId)}
          />
        );
      })}
    </div>
  );
};

export default PokemonList;
