import React from "react";
import styles from "./PokemonCard.module.css";
import { getPokemonDetailsResponse } from "../../../api/pokemon/pokemon.response.types";

interface PokemonCardProps extends Omit<getPokemonDetailsResponse, "sprites"> {
  sprites: {
    front_default: string;
  };
  onClick: () => void;
}

const PokemonCard: React.FC<PokemonCardProps> = ({
  id,
  name,
  types,
  sprites,
  onClick,
}) => {
  return (
    <div className={styles.card} onClick={onClick}>
      <img src={sprites.front_default} alt={name} className={styles.image} />
      <div className={styles.info}>
        <p className={styles.number}>#{String(id).padStart(3, "0")}</p>
        <h3 className={styles.name}>{name}</h3>
        <div className={styles.types}>
          {types.map((type, index) => (
            <div key={index} className={styles.type}>
              <span>{type.type.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PokemonCard;
