import React, { useState, useEffect } from "react";
import { getPokemonDetailsResponse } from "../../../api/pokemon/pokemon.response.types";

interface PokemonModalProps {
  pokemonId: number;
  onClose: () => void;
}

const PokemonModal: React.FC<PokemonModalProps> = ({ pokemonId, onClose }) => {
  const [pokemon, setPokemon] = useState<getPokemonDetailsResponse | null>(
    null
  );

  useEffect(() => {
    const fetchPokemonDetails = async () => {
      const response = await fetch(
        `https://pokeapi.co/api/v2/pokemon/${pokemonId}`
      );
      const data: getPokemonDetailsResponse = await response.json();
      setPokemon(data);
    };

    fetchPokemonDetails();
  }, [pokemonId]);

  if (!pokemon) return null;

  return (
    <div className="modal" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="close-button">
          X
        </button>
        <img src={pokemon.sprites.front_default} alt={pokemon.name} />
        <h2>{pokemon.name}</h2>
        <p>Height: {pokemon.height}m</p>
        <p>Weight: {pokemon.weight}kg</p>
      </div>
    </div>
  );
};

export default PokemonModal;
