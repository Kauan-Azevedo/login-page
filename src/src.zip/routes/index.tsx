import { useEffect, useState } from "react";
import { setupAuthListener } from "../api/auth/auth.service";
import { isAuthenticated, signOut } from "../api/auth/auth.service";
import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import "../css/styles.css";

import Navbar from "../components/Navbar";
import Content from "../components/Content";
import PokemonList from "../components/pokemon/PokemonList";
import PokemonDetailsModal from "../components/pokemon/PokemonDetailsModal";
import {
  getPokemonList,
  getPokemonDetails,
} from "../api/pokemon/pokemon.service";
import {
  getPokemonListResponse,
  getPokemonDetailsResponse,
} from "../api/pokemon/pokemon.response.types";

export const Route = createFileRoute("/")({
  beforeLoad: async () => {
    const authenticated = await isAuthenticated();
    if (!authenticated) throw redirect({ to: "/auth" });
  },
  component: HomeComponent,
});

function HomeComponent() {
  const navigate = useNavigate({ from: "/" });

  const [pokemonList, setPokemonList] = useState<getPokemonListResponse | null>(
    null
  );
  const [selectedPokemon, setSelectedPokemon] =
    useState<getPokemonDetailsResponse | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const listData = await getPokemonList();
      setPokemonList(listData);
    };

    fetchData();
    const unsubscribe = setupAuthListener();
    return () => unsubscribe();
  }, []);

  const handleCardClick = async (id: number) => {
    const detailsData = await getPokemonDetails(id);
    setSelectedPokemon(detailsData);
    setShowDetailsModal(true);
  };

  const handleCloseModal = () => {
    setShowDetailsModal(false);
  };

  return (
    <div>
      <Navbar />
      <Content>
        <h1>Pokémon Data</h1>
        {pokemonList && (
          <PokemonList data={pokemonList} onCardClick={handleCardClick} />
        )}
        {selectedPokemon && (
          <PokemonDetailsModal
            data={selectedPokemon}
            onClose={handleCloseModal}
          />
        )}
      </Content>
    </div>
  );
}

export default HomeComponent;
